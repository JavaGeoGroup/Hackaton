var myCode;
var myAmount;
var avlAmount = 50;
var val1;

function generateCode(){
    var myCode = Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
    document.getElementById("myContent").innerHTML = "თანხა: 50GEL;  დარჩენილი დრო: 2 საათი; გადახდის კოდი:" + myCode;
    return myCode;
  };

  function generateTransaction(){
      if(avlAmount < 50){
        window.alert("You dont have enough amount");
      }else{
        myAmount = document.getElementById('amount').value;
        val1 = myAmount;
      }
      myAmount = 980;
      return myAmount;
  };


  function getBalances() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        var json = JSON.parse(this.responseText);
        //var amount =  json.AvailableAmounts[0].Amount;
        avlAmount = json["0"].AvailableAmounts[0].Amount
        document.getElementById("avAmount").innerHTML=  json["0"].AvailableAmounts[0].Amount;
        // document.getElementById("amnt").innerHTML=  json["0"].AvailableAmounts[0].Amount + " ₾";
        // document.getElementById("lDuty").innerHTML=  "29,476.52" + " ₾";

}
};
xhttp.open("GET", "https://api.fintech.ge/api/Products/Accounts/AQIC5wM2LY4Sfczsz_vdCMso9AWlYSTzVn8a1cm3YCJ48DM", true);
xhttp.send();    
};

